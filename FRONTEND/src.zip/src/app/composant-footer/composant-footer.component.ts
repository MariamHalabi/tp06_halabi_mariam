import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-composant-footer',
  templateUrl: './composant-footer.component.html',
  styleUrls: ['./composant-footer.component.css']
})
export class ComposantFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

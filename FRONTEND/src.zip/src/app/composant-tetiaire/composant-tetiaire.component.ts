import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-composant-tetiaire',
  templateUrl: './composant-tetiaire.component.html',
  styleUrls: ['./composant-tetiaire.component.css']
})
export class ComposantTetiaireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

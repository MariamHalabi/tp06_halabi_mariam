import { Directive, HostListener, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appCtrlDataDirective]',
})
export class CtrlDataDirectiveDirective {
  constructor(private _elemnt: ElementRef) {}

  @Input() appCtrlDataDirective: boolean = false;

  @HostListener('click') onclick() {
    if (this.appCtrlDataDirective)
      this._elemnt.nativeElement.style.borderColor = 'red';
  }
}
